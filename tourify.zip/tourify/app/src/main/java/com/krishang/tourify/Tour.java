package com.krishang.tourify;



import java.io.Serializable;

public class Tour implements Serializable {
    private String name;
    private String description;
    private double price;

    public Tour(String name, String description, double price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public double getPrice() {
        return price;
    }
}
