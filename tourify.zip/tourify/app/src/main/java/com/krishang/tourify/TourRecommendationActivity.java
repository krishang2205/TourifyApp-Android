package com.krishang.tourify;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.krishang.tourify.UserPreferences;

import java.util.ArrayList;
import java.util.List;

public class TourRecommendationActivity extends AppCompatActivity {

    private ListView listViewTours;
    private TextView textViewTours;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tour_recommendation);

        listViewTours = findViewById(R.id.listViewTours);
        textViewTours = findViewById(R.id.textViewTours);

        UserPreferences userPreferences = (UserPreferences) getIntent().getSerializableExtra("userPreferences");
        List<String> recommendations = getTourRecommendations(userPreferences);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, recommendations);
        listViewTours.setAdapter(adapter);
    }

    private List<String> getTourRecommendations(UserPreferences userPreferences) {
        // Here you would normally call an API or database to get the actual recommendations
        List<String> tours = new ArrayList<>();
        tours.add("City Tour - $50");
        tours.add("Beach Tour - $40");
        tours.add("Museum Tour - $30");
        return tours;
    }
}