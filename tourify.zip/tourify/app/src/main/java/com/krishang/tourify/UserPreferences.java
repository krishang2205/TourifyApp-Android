package com.krishang.tourify;



import java.io.Serializable;

public class UserPreferences implements Serializable {
    private String travelDate;
    private String budget;
    private String interests;

    public UserPreferences(String travelDate, String budget, String interests) {
        this.travelDate = travelDate;
        this.budget = budget;
        this.interests = interests;
    }

    // Getters
    public String getTravelDate() {
        return travelDate;
    }

    public String getBudget() {
        return budget;
    }

    public String getInterests() {
        return interests;
    }
}

